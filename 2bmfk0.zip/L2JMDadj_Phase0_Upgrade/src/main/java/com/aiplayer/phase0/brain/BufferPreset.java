package com.aiplayer.phase0.brain;

import com.aiplayer.phase0.cabinet.BotProfile;

public class BufferPreset extends ClassPreset {
    private int buffCycle = 0;

    public BufferPreset(BotProfile profile) { super(profile); }

    @Override
    public int selectSkill(int hpPercent, int mpPercent, double distance, boolean targetIsMob) {
        if (mpPercent < 15) return -1;
        buffCycle++;
        if (buffCycle % 3 == 0) return MIGHT;
        if (buffCycle % 3 == 1) return HASTE;
        return FOCUS;
    }

    @Override
    public double getOptimalDistance() { return 200.0; }

    @Override
    public boolean useShots() { return false; }
}
