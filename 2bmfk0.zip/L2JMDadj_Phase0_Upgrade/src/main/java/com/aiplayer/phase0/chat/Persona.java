package com.aiplayer.phase0.chat;

public enum Persona {
    VETERAN, NEWBIE, TROLL, ROLEPLAYER, MERCHANT
}
