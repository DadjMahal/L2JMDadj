package com.aiplayer.phase0.cabinet;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import java.util.Map;
import java.util.UUID;

/**
 * L1 Hot state cache.
 * Phase 0: single JedisPool, no Sentinel.
 */
public class RedisCache {
    private static RedisCache instance;
    private final JedisPool pool;

    private RedisCache() {
        String host = System.getProperty("redis.host", "localhost");
        int port = Integer.parseInt(System.getProperty("redis.port", "6379"));
        this.pool = new JedisPool(new JedisPoolConfig(), host, port);
    }

    public static synchronized RedisCache getInstance() {
        if (instance == null) instance = new RedisCache();
        return instance;
    }

    public void cacheProfile(BotProfile p) {
        try (Jedis j = pool.getResource()) {
            String key = "cabinet:profile:" + p.getAccountName();
            j.hset(key, "bot_id", p.getBotId().toString());
            j.hset(key, "name", p.getName());
            j.hset(key, "class_current", String.valueOf(p.getClassCurrent()));
            j.hset(key, "level", String.valueOf(p.getLevel()));
            j.hset(key, "persona", p.getPersona());
            j.expire(key, 3600);
        }
    }

    public BotProfile getProfile(String accountName) {
        try (Jedis j = pool.getResource()) {
            String key = "cabinet:profile:" + accountName;
            Map<String, String> h = j.hgetAll(key);
            if (h == null || h.isEmpty()) return null;
            return new BotProfile(
                UUID.fromString(h.get("bot_id")),
                h.get("name"),
                accountName,
                Integer.parseInt(h.getOrDefault("race", "0")),
                Integer.parseInt(h.getOrDefault("class_current", "0")),
                0,
                Integer.parseInt(h.getOrDefault("level", "1")),
                20,
                h.getOrDefault("persona", "Veteran"),
                0.5, 0.5, 0.1
            );
        } catch (Exception e) {
            return null;
        }
    }

    public void setBotState(String accountName, String field, String value) {
        try (Jedis j = pool.getResource()) {
            j.hset("bot:state:" + accountName, field, value);
            j.expire("bot:state:" + accountName, 3600);
        }
    }

    public String getBotState(String accountName, String field) {
        try (Jedis j = pool.getResource()) {
            return j.hget("bot:state:" + accountName, field);
        }
    }

    public void pushChat(String accountName, String line) {
        try (Jedis j = pool.getResource()) {
            String key = "bot:chat:" + accountName;
            j.lpush(key, line);
            j.ltrim(key, 0, 9);
            j.expire(key, 3600);
        }
    }

    public JedisPool getPool() { return pool; }
}
