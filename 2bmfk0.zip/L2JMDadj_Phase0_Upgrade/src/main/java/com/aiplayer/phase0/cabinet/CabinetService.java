package com.aiplayer.phase0.cabinet;

import java.sql.*;
import java.util.*;
import java.util.logging.Logger;

/**
 * Player Cabinet Service — PostgreSQL cold storage + Redis hot cache.
 * Phase 0: simplified, no pgvector yet.
 */
public class CabinetService {
    private static final Logger LOGGER = Logger.getLogger(CabinetService.class.getName());
    private static CabinetService instance;
    private final String jdbcUrl;
    private final String jdbcUser;
    private final String jdbcPass;
    private final RedisCache redis;

    private CabinetService() {
        this.jdbcUrl = System.getProperty("cabinet.jdbc.url", "jdbc:postgresql://localhost:5432/ai_cabinet");
        this.jdbcUser = System.getProperty("cabinet.jdbc.user", "ai_user");
        this.jdbcPass = System.getProperty("cabinet.jdbc.pass", "ai_pass");
        this.redis = RedisCache.getInstance();
        initTables();
    }

    public static synchronized CabinetService getInstance() {
        if (instance == null) instance = new CabinetService();
        return instance;
    }

    private void initTables() {
        try (Connection c = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPass)) {
            LOGGER.info("Cabinet DB connected: " + jdbcUrl);
        } catch (SQLException e) {
            LOGGER.severe("Cabinet DB connection failed: " + e.getMessage());
        }
    }

    public BotProfile loadProfile(String accountName) {
        BotProfile cached = redis.getProfile(accountName);
        if (cached != null) return cached;

        String sql = "SELECT bot_id,name,account_name,race,class_current,class_target,level,level_goal,persona,personality FROM ai_cabinet.ai_profiles WHERE account_name = ? AND is_active = TRUE";
        try (Connection c = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPass);
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, accountName);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Map<String, Double> pers = parsePersonality(rs.getString("personality"));
                BotProfile p = new BotProfile(
                    UUID.fromString(rs.getString("bot_id")),
                    rs.getString("name"),
                    rs.getString("account_name"),
                    rs.getInt("race"),
                    rs.getInt("class_current"),
                    rs.getInt("class_target"),
                    rs.getInt("level"),
                    rs.getInt("level_goal"),
                    rs.getString("persona"),
                    pers.getOrDefault("aggressive", 0.5),
                    pers.getOrDefault("friendly", 0.5),
                    pers.getOrDefault("troll", 0.1)
                );
                redis.cacheProfile(p);
                return p;
            }
        } catch (SQLException e) {
            LOGGER.warning("Failed to load profile: " + e.getMessage());
        }
        return null;
    }

    public void recordEpisode(UUID botId, String eventType, String description, String location, String involvedPlayer, String emotionalTag) {
        String sql = "INSERT INTO ai_cabinet.ai_episodes (bot_id,event_type,description,location,involved_player,emotional_tag) VALUES (?,?,?,?,?,?)";
        try (Connection c = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPass);
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setObject(1, botId);
            ps.setString(2, eventType);
            ps.setString(3, description);
            ps.setString(4, location);
            ps.setString(5, involvedPlayer);
            ps.setString(6, emotionalTag);
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.warning("Episode record failed: " + e.getMessage());
        }
    }

    public void updateRelation(UUID botId, String targetName, int trustDelta, String tag) {
        String upsert = "INSERT INTO ai_cabinet.ai_relations (bot_id,target_name,trust_score,tags,last_interaction) VALUES (?,?,?,ARRAY[?],NOW()) " +
                "ON CONFLICT (bot_id,target_name) DO UPDATE SET trust_score = ai_cabinet.ai_relations.trust_score + EXCLUDED.trust_score, " +
                "tags = array_distinct(ai_cabinet.ai_relations.tags || EXCLUDED.tags), last_interaction = NOW()";
        try (Connection c = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPass);
             PreparedStatement ps = c.prepareStatement(upsert)) {
            ps.setObject(1, botId);
            ps.setString(2, targetName);
            ps.setInt(3, trustDelta);
            ps.setString(4, tag);
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.warning("Relation update failed: " + e.getMessage());
        }
    }

    public List<BotProfile> loadAllActive() {
        List<BotProfile> list = new ArrayList<>();
        String sql = "SELECT bot_id,name,account_name,race,class_current,class_target,level,level_goal,persona,personality FROM ai_cabinet.ai_profiles WHERE is_active = TRUE";
        try (Connection c = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPass);
             Statement s = c.createStatement();
             ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) {
                Map<String, Double> pers = parsePersonality(rs.getString("personality"));
                list.add(new BotProfile(
                    UUID.fromString(rs.getString("bot_id")),
                    rs.getString("name"),
                    rs.getString("account_name"),
                    rs.getInt("race"),
                    rs.getInt("class_current"),
                    rs.getInt("class_target"),
                    rs.getInt("level"),
                    rs.getInt("level_goal"),
                    rs.getString("persona"),
                    pers.getOrDefault("aggressive", 0.5),
                    pers.getOrDefault("friendly", 0.5),
                    pers.getOrDefault("troll", 0.1)
                ));
            }
        } catch (SQLException e) {
            LOGGER.warning("Load all failed: " + e.getMessage());
        }
        return list;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Double> parsePersonality(String json) {
        Map<String, Double> m = new HashMap<>();
        if (json == null) return m;
        json = json.replace("{", "").replace("}", "").replace(""", "");
        for (String pair : json.split(",")) {
            String[] kv = pair.split(":");
            if (kv.length == 2) {
                try { m.put(kv[0].trim(), Double.parseDouble(kv[1].trim())); } catch (NumberFormatException ignored) {}
            }
        }
        return m;
    }
}
