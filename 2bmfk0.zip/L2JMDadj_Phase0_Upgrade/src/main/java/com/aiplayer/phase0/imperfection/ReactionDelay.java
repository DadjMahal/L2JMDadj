package com.aiplayer.phase0.imperfection;

import java.util.Random;

public class ReactionDelay {
    private final Random rng = new Random();
    private long delayUntil = 0;

    public boolean shouldDelay() {
        long now = System.currentTimeMillis();
        if (now < delayUntil) return true;
        if (rng.nextDouble() < 0.30) {
            int delayMs = 50 + rng.nextInt(250);
            delayUntil = now + delayMs;
            return true;
        }
        return false;
    }
}
