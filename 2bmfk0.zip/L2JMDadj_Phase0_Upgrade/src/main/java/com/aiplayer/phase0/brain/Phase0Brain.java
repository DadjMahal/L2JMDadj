package com.aiplayer.phase0.brain;

import com.aiplayer.phase0.cabinet.BotProfile;
import com.aiplayer.phase0.cabinet.CabinetService;
import com.aiplayer.phase0.imperfection.ImperfectionInjector;

import java.util.logging.Logger;

/**
 * Phase 0 Brain — replaces the over-engineered AIBrain for bootstrap.
 * Uses FSM + class presets. Zero neural networks. Zero LLM.
 */
public class Phase0Brain {
    private static final Logger LOGGER = Logger.getLogger(Phase0Brain.class.getName());

    private final String accountName;
    private final BotProfile profile;
    private final StateMachine fsm;
    private final ClassPreset combatPreset;
    private final ImperfectionInjector imperfections;
    private final CabinetService cabinet;

    private int hpPercent = 100;
    private int mpPercent = 100;
    private double targetDistance = 9999;
    private boolean targetAlive = false;
    private boolean targetInRange = false;
    private boolean chatPending = false;
    private boolean partyInvitePending = false;
    private boolean isDead = false;

    public Phase0Brain(String accountName) {
        this.accountName = accountName;
        this.cabinet = CabinetService.getInstance();
        this.profile = cabinet.loadProfile(accountName);
        this.fsm = new StateMachine();
        this.combatPreset = PresetFactory.forProfile(profile);
        this.imperfections = new ImperfectionInjector();
    }

    public String think() {
        if (profile == null) return "IDLE";
        if (imperfections.isAFK()) return "IDLE";
        if (imperfections.shouldDelay()) return "IDLE";

        BotState state = fsm.tick(profile, hpPercent, mpPercent, targetInRange, targetAlive,
                                 chatPending, partyInvitePending, isDead);

        switch (state) {
            case IDLE:  return doIdle();
            case FARM:  return doFarm();
            case COMBAT: return doCombat();
            case RETREAT: return doRetreat();
            case SOCIAL: return doSocial();
            case DEATH: return doDeath();
            default: return "IDLE";
        }
    }

    private String doIdle() {
        if (Math.random() < 0.1) {
            int dx = (int)(Math.random() * 200 - 100);
            int dy = (int)(Math.random() * 200 - 100);
            return "MOVE_REL " + dx + " " + dy + " 0";
        }
        return "IDLE";
    }

    private String doFarm() {
        if (targetInRange && targetAlive) {
            fsm.transition(BotState.COMBAT);
            return doCombat();
        }
        int dx = (int)(Math.random() * 600 - 300);
        int dy = (int)(Math.random() * 600 - 300);
        return "MOVE_REL " + dx + " " + dy + " 0";
    }

    private String doCombat() {
        if (!targetAlive) return "LOOT";
        int skill = combatPreset.selectSkill(hpPercent, mpPercent, targetDistance, true);
        if (skill > 0) return "SKILL " + skill + " TARGET";
        return "ATTACK TARGET";
    }

    private String doRetreat() {
        if (Math.random() < 0.3) return "USE_ITEM RETURN_SCROLL";
        int dx = (int)(Math.random() * 800 + 200);
        int dy = (int)(Math.random() * 800 + 200);
        return "MOVE_REL " + dx + " " + dy + " 0";
    }

    private String doSocial() {
        if (fsm.getTimeInState() > 5000) {
            chatPending = false;
            partyInvitePending = false;
            fsm.transition(BotState.IDLE);
        }
        return "IDLE";
    }

    private String doDeath() {
        if (Math.random() < 0.05) return "RESPAWN";
        return "IDLE";
    }

    public void updateHP(int percent) { this.hpPercent = percent; }
    public void updateMP(int percent) { this.mpPercent = percent; }
    public void updateTarget(boolean inRange, boolean alive, double distance) {
        this.targetInRange = inRange;
        this.targetAlive = alive;
        this.targetDistance = distance;
    }
    public void onChatReceived() { this.chatPending = true; }
    public void onPartyInvite() { this.partyInvitePending = true; }
    public void onDeath() { this.isDead = true; }
    public void onRespawn() { this.isDead = false; this.hpPercent = 100; fsm.transition(BotState.IDLE); }

    public BotProfile getProfile() { return profile; }
    public BotState getState() { return fsm.getState(); }
    public String getAccountName() { return accountName; }
}
