package com.aiplayer.phase0.brain;

import com.aiplayer.phase0.cabinet.BotProfile;

public class ArcherPreset extends ClassPreset {
    public ArcherPreset(BotProfile profile) { super(profile); }

    @Override
    public int selectSkill(int hpPercent, int mpPercent, double distance, boolean targetIsMob) {
        if (mpPercent < 10) return -1;
        return POWER_SHOT;
    }

    @Override
    public double getOptimalDistance() { return 650.0; }

    @Override
    public boolean useShots() { return true; }
}
