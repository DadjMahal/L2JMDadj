package com.aiplayer.phase0.protocol;

import java.util.Random;

public class PacketJitter {
    private final Random rng = new Random();
    private final double sigmaMs;

    public PacketJitter(double sigmaMs) {
        this.sigmaMs = sigmaMs;
    }

    public long nextDelayMs() {
        long d = Math.round(rng.nextGaussian() * sigmaMs);
        return Math.max(0, d);
    }

    public void sleep() {
        try {
            Thread.sleep(nextDelayMs());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
