package com.aiplayer.phase0.brain;

/**
 * Phase 0 Finite State Machine states.
 */
public enum BotState {
    IDLE,
    FARM,
    COMBAT,
    DEATH,
    SOCIAL,
    RETREAT
}
