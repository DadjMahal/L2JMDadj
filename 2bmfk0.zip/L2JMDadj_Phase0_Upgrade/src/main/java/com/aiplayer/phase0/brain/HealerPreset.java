package com.aiplayer.phase0.brain;

import com.aiplayer.phase0.cabinet.BotProfile;

public class HealerPreset extends ClassPreset {
    public HealerPreset(BotProfile profile) { super(profile); }

    @Override
    public int selectSkill(int hpPercent, int mpPercent, double distance, boolean targetIsMob) {
        if (hpPercent < 50 && mpPercent > 20) return BATTLE_HEAL;
        if (mpPercent > 10) return HEAL;
        return -1;
    }

    @Override
    public double getOptimalDistance() { return 400.0; }

    @Override
    public boolean useShots() { return false; }
}
