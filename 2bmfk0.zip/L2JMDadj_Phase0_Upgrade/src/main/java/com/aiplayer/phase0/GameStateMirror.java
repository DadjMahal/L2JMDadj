package com.aiplayer.phase0;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Mirrors game state from parsed server packets.
 * CombatAI and SocialAI read from here instead of using mock data.
 *
 * Updated by the packet reader thread when StatusUpdate, CharInfo,
 * NPC_INFO, Die, Revive packets arrive.
 */
public class GameStateMirror {
    private static final GameStateMirror INSTANCE = new GameStateMirror();
    public static GameStateMirror getInstance() { return INSTANCE; }

    private final ConcurrentHashMap<String, BotStateSnapshot> bots = new ConcurrentHashMap<>();

    public BotStateSnapshot get(String botName) {
        return bots.computeIfAbsent(botName, k -> new BotStateSnapshot());
    }

    public void updateHP(String botName, int current, int max) {
        BotStateSnapshot s = get(botName);
        s.hpCurrent = current;
        s.hpMax = max;
    }

    public void updateMP(String botName, int current, int max) {
        BotStateSnapshot s = get(botName);
        s.mpCurrent = current;
        s.mpMax = max;
    }

    public void updatePosition(String botName, int x, int y, int z) {
        BotStateSnapshot s = get(botName);
        s.x = x; s.y = y; s.z = z;
    }

    public void setTarget(String botName, int targetObjId, boolean isMob) {
        BotStateSnapshot s = get(botName);
        s.targetObjId = targetObjId;
        s.targetIsMob = isMob;
        s.hasTarget = targetObjId != 0;
    }

    public void setDead(String botName, boolean dead) {
        get(botName).isDead = dead;
    }

    public void addNearbyEntity(String botName, int objId, String name, int x, int y, int z, boolean isMob) {
        get(botName).nearby.put(objId, new EntitySnapshot(objId, name, x, y, z, isMob));
    }

    public void removeEntity(String botName, int objId) {
        get(botName).nearby.remove(objId);
    }

    public static class BotStateSnapshot {
        public volatile int hpCurrent = 100, hpMax = 100;
        public volatile int mpCurrent = 100, mpMax = 100;
        public volatile int x, y, z;
        public volatile int targetObjId = 0;
        public volatile boolean hasTarget = false;
        public volatile boolean targetIsMob = true;
        public volatile boolean isDead = false;
        public final ConcurrentHashMap<Integer, EntitySnapshot> nearby = new ConcurrentHashMap<>();
    }

    public static class EntitySnapshot {
        public final int objId;
        public final String name;
        public final int x, y, z;
        public final boolean isMob;

        public EntitySnapshot(int objId, String name, int x, int y, int z, boolean isMob) {
            this.objId = objId; this.name = name; this.x = x; this.y = y; this.z = z; this.isMob = isMob;
        }
    }
}
