# WHY We Are Doing This — Big Picture

## The Problem With Current Code
Your existing AI engine has excellent architecture:
- AIBrain with priority-based decisions
- CombatAI with 12 action types
- SocialAI with party/clan/trade logic
- Real L2 protocol connection

But it has ONE critical gap: **it operates on mock data**.
CombatAI uses `getSimulatedHP()` instead of real HP from the server.
SocialAI has no chat response system.
AIPlayerManager ticks every bot every 100ms regardless of state.

This means bots look robotic because they CANNOT react to real game events.

## What Phase 0 Fixes

### 1. Real State Awareness (GameStateMirror)
Before: Bot thinks it has 100% HP always.
After: Bot reads actual HP from StatusUpdate packets and retreats at 25%.

### 2. Missing Protocol Methods (Phase0ProtocolExt)
Before: Bot can move, attack, chat. Cannot use skills, items, or respawn.
After: Bot can cast Wind Strike, use Return Scroll, respawn at village.

### 3. Chat That Feels Human (ChatEngine)
Before: Bots are mute. SocialAI has no reply logic.
After: Bots respond to "buff" with "1 sec" (Veteran) or "sure! buffing now" (Newbie).

### 4. Persistent Identity (CabinetService)
Before: Bots are hardcoded in Java. Restart = reset.
After: Bot profiles live in PostgreSQL. Restart = bots resume with same level/class/goals.

### 5. CPU Efficiency (Priority Scheduler)
Before: 100 bots x 10 ticks/sec = 1000 ticks/sec always.
After: Combat bots tick 4x/sec, idle bots 1x/sec. 70% CPU reduction.

### 6. Human Imperfection (ImperfectionInjector)
Before: Bots react instantly, never AFK, never typo.
After: 50-300ms reaction delay, 5% chance of 2-5 min AFK, 10% chat typos.

## The Goal
Phase 0 makes your existing AI architecture **actually work** with real game data.
It is NOT a rewrite. It is wiring.

Once Phase 0 is stable (100 bots, believable combat + chat), Phase 1 adds:
- Behavior Trees + Utility Scoring (replace FSM in CombatAI)
- GOAP for long-term goals
- vLLM for natural language chat
- Director AI ecology management

But NONE of that works without Phase 0. Phase 0 is the foundation.
