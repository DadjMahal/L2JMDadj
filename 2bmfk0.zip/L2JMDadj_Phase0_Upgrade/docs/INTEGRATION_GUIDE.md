# Phase 0 Integration Guide
## L2JMDadj AI Player System — Zero-LLM Bootstrap

### What This Is
Phase 0 is the foundation layer. It does NOT replace your existing AI modules (CombatAI, SocialAI, AIBrain). Instead, it **feeds them real game state** from parsed server packets and adds missing pieces: chat responses, persistence, and smarter scheduling.

### Prerequisites
- PostgreSQL 16+ running
- Redis 7+ running on localhost:6379
- L2JMobius LoginServer + GameServer running
- Maven 3.8+

### Step 1: Database Setup
```bash
psql -U postgres -d ai_cabinet -f sql/01_ai_cabinet_schema.sql
psql -U postgres -d ai_cabinet -f sql/02_seed_presets.sql
```

### Step 2: Create LoginServer Accounts
The seed SQL uses accounts ai_p01 through ai_p10. Create matching accounts in your L2JMobius loginserver.accounts table:
```sql
INSERT INTO accounts (login, password, access_level) VALUES
('ai_p01', 'ai123pass', 0),
('ai_p02', 'ai123pass', 0),
...
```

### Step 3: Add Dependencies
Copy the contents of `pom_additions.xml` into your existing `AIPlayerEngine/pom.xml` inside the `<dependencies>` block.

### Step 4: Copy New Source Files
Copy `src/main/java/com/aiplayer/phase0/` into your `AIPlayerEngine/src/main/java/com/aiplayer/` directory.

### Step 5: Apply Patches
Follow the instructions in each PATCH.txt file:
1. `patch/L2JProtocol_PATCH.txt` — add 5 new packet methods
2. `patch/AIPlayer_PATCH.txt` — wire GameStateMirror + ChatEngine
3. `patch/AIPlayerManager_PATCH.txt` — priority scheduler + cabinet spawn
4. `patch/CombatAI_PATCH.txt` — replace mock HP with real state
5. `patch/PacketReader_PATCH.txt` — feed parsed packets into GameStateMirror

### Step 6: Build
```bash
cd AIPlayerEngine
mvn clean compile
```

### Step 7: Run
```bash
# Start L2JMobius servers first
./StartServer.sh

# Then launch AI Engine
mvn exec:java -Dexec.mainClass=com.aiplayer.engine.AIPlayerEngine -Dexec.args="--spawn-all"
```

### Architecture Overview
```
[Server Packets] ---> [Packet Reader] ---> [GameStateMirror] ---> [CombatAI/SocialAI]
                                              |
                                              v
[PostgreSQL] <--> [CabinetService] <--> [RedisCache] <--> [ChatEngine]
                                              |
                                              v
                                        [DirectorAI] ---> [AIPlayerManager]
```

### Zero LLM Guarantee
- No GPU required
- No Ollama/vLLM running
- Chat is 100% regex + template pools
- All combat decisions use existing CombatAI, just with real data
