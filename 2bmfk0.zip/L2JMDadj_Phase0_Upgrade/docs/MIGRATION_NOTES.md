# Migration Notes: Existing Code -> Phase 0

## What We Added (New Code)
| Component | Purpose |
|-----------|---------|
| GameStateMirror | Live game state from parsed packets |
| Phase0ProtocolExt | Missing packet encoders (skill, item, respawn) |
| CabinetService | PostgreSQL persistence for bot profiles |
| RedisCache | Hot state cache (< 5ms reads) |
| ChatEngine | Regex intent + persona templates |
| DirectorAI | Spawn queue from database |
| ImperfectionInjector | Reaction delay + AFK simulation |

## What We Modified (Patches)
| File | Change |
|------|--------|
| L2JProtocol | Added sendSkillUse, sendUseItem, sendRequestRestartPoint, sendValidatePosition |
| AIPlayer | Wired GameStateMirror, ChatEngine, CabinetService |
| AIPlayerManager | Priority scheduler + spawnFromCabinet() |
| CombatAI | Replaced mock HP with GameStateMirror reads |
| Packet Reader | Added hooks to feed GameStateMirror |

## What We Kept Unchanged
- AIBrain priority logic
- SocialAI decision structure
- QuestAI / MerchantAI modules
- L2JProtocol existing methods (move, attack, chat)
- AIPlayerActionExecutor
- AIMonitorDashboard
- PerformanceMetrics

## Rollback Plan
If Phase 0 fails:
1. Revert AIPlayer.think() to old body
2. Remove GameStateMirror and ChatEngine fields
3. Restore AIPlayerManager.thinkAllPlayers() flat loop
4. Delete com.aiplayer.phase0 package entirely

## Phase 1 Upgrade Path
Phase 0 -> Phase 1 is drop-in:
1. Replace ChatEngine templates with vLLM bridge (same interface)
2. Add GOAP planner alongside existing CombatAI
3. Add pgvector semantic search to CabinetService
4. Keep GameStateMirror — it becomes the perception layer for BT/Utility
