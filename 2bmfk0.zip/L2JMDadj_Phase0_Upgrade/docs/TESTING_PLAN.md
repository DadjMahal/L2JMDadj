# Phase 0 Testing Plan

## Test 1: Cabinet Connectivity
```bash
psql -U ai_user -d ai_cabinet -c "SELECT COUNT(*) FROM ai_profiles;"
```
**Expected:** 10 rows

## Test 2: Redis Connectivity
```bash
redis-cli ping
```
**Expected:** PONG

## Test 3: Build
```bash
mvn clean compile
```
**Expected:** BUILD SUCCESS, 0 errors

## Test 4: Spawn 1 Bot
```java
AIPlayerManager.getInstance().spawnFromCabinet();
```
**Expected Log:**
```
[INFO] Director: 10 bot profiles in cabinet
[INFO] [L2JM CONNECTION] XxDarkSlayerxX successfully connected
[INFO] [Real Protocol] AI Player created: XxDarkSlayerxX
```

## Test 5: GameStateMirror Updates
Kill a mob near a bot and check:
```java
GameStateMirror.getInstance().get("XxDarkSlayerxX").hpCurrent
```
**Expected:** Value changes when StatusUpdate packet is parsed

## Test 6: Chat Response
In-game: Whisper "buff" to SweetHealer
**Expected Response:** "buffing" or "1 sec" or "ok, buffing now"

## Test 7: Priority Tick Rates
```bash
grep "think" ai_engine.log | awk '{print $4}'
```
**Expected:** Combat bots tick every 250ms, idle bots every 1000ms

## Test 8: Death & Respawn
Kill a bot in-game
**Expected:** GameStateMirror marks isDead=true, bot attempts respawn via sendRequestRestartPoint()

## Test 9: 10 Bot Stress
Spawn all 10 cabinet bots
**Expected:** GameServer TPS stays above 20, no connection drops

## Success Criteria
| Metric | Target |
|--------|--------|
| Build | BUILD SUCCESS |
| DB connection | < 50ms |
| Redis read | < 5ms |
| Bot spawn | 10/10 connect |
| Chat response | < 100ms |
| TPS impact | < 5% drop |
