-- Phase 0 Player Cabinet Schema
-- Run this against your PostgreSQL (can be same server as L2JMobius, separate DB)

CREATE SCHEMA IF NOT EXISTS ai_cabinet;

CREATE TABLE IF NOT EXISTS ai_cabinet.ai_profiles (
    bot_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(35) UNIQUE NOT NULL,
    account_name VARCHAR(35) NOT NULL,
    race SMALLINT NOT NULL DEFAULT 0,
    class_current SMALLINT NOT NULL DEFAULT 0,
    class_target SMALLINT,
    level INT DEFAULT 1,
    level_goal INT DEFAULT 20,
    personality JSONB DEFAULT '{"aggressive":0.5,"friendly":0.5,"troll":0.1}',
    play_schedule JSONB DEFAULT '{"start_hour":18,"end_hour":23,"timezone":"+03"}',
    persona VARCHAR(16) DEFAULT 'Veteran',
    is_main_char BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    is_online BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    last_login TIMESTAMPTZ,
    last_logout TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS ai_cabinet.ai_goals (
    goal_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    bot_id UUID REFERENCES ai_cabinet.ai_profiles(bot_id) ON DELETE CASCADE,
    goal_type VARCHAR(32) NOT NULL,
    target_value INT,
    current_progress INT DEFAULT 0,
    status VARCHAR(16) DEFAULT 'ACTIVE',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ai_cabinet.ai_episodes (
    episode_id BIGSERIAL PRIMARY KEY,
    bot_id UUID REFERENCES ai_cabinet.ai_profiles(bot_id) ON DELETE CASCADE,
    event_type VARCHAR(32) NOT NULL,
    description TEXT,
    location VARCHAR(64),
    involved_player VARCHAR(35),
    emotional_tag VARCHAR(16),
    created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_episodes_bot_time ON ai_cabinet.ai_episodes(bot_id, created_at DESC);

CREATE TABLE IF NOT EXISTS ai_cabinet.ai_relations (
    bot_id UUID REFERENCES ai_cabinet.ai_profiles(bot_id) ON DELETE CASCADE,
    target_name VARCHAR(35) NOT NULL,
    trust_score INT DEFAULT 0,
    tags TEXT[],
    last_interaction TIMESTAMPTZ,
    PRIMARY KEY (bot_id, target_name)
);

CREATE TABLE IF NOT EXISTS ai_cabinet.ai_analytics (
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    bot_id UUID REFERENCES ai_cabinet.ai_profiles(bot_id) ON DELETE CASCADE,
    metric_type VARCHAR(32) NOT NULL,
    value INT,
    zone VARCHAR(64),
    context JSONB
);
CREATE INDEX IF NOT EXISTS idx_analytics_bot_time ON ai_cabinet.ai_analytics(bot_id, timestamp DESC);
