-- Seed 10 realistic bot accounts for Phase 0 testing
-- IMPORTANT: Create matching accounts in loginserver.accounts table too!

INSERT INTO ai_cabinet.ai_profiles (name, account_name, race, class_current, class_target, level, level_goal, persona, personality)
VALUES
('XxDarkSlayerxX', 'ai_p01', 2, 32, 43, 35, 40, 'Veteran', '{"aggressive":0.7,"friendly":0.3,"troll":0.2}'),
('SweetHealer',      'ai_p02', 0, 25, 29, 28, 40, 'Newbie', '{"aggressive":0.1,"friendly":0.9,"troll":0.0}'),
('ArrowOfDoom',      'ai_p03', 1, 18, 23, 32, 40, 'Veteran', '{"aggressive":0.8,"friendly":0.2,"troll":0.3}'),
('BuffLord',         'ai_p04', 0, 16, 20, 24, 40, 'Roleplayer', '{"aggressive":0.2,"friendly":0.8,"troll":0.0}'),
('NoobKiller',       'ai_p05', 2, 31, 43, 38, 52, 'Troll', '{"aggressive":0.9,"friendly":0.1,"troll":0.9}'),
('MageQueen',        'ai_p06', 2, 11, 12, 30, 40, 'Veteran', '{"aggressive":0.6,"friendly":0.4,"troll":0.1}'),
('TankyBoy',         'ai_p07', 0, 3, 5, 26, 40, 'Newbie', '{"aggressive":0.4,"friendly":0.7,"troll":0.0}'),
('ShadowStep',       'ai_p08', 2, 35, 36, 36, 40, 'Veteran', '{"aggressive":0.8,"friendly":0.2,"troll":0.2}'),
('HolyLight',        'ai_p09', 0, 15, 17, 22, 40, 'Roleplayer', '{"aggressive":0.1,"friendly":0.9,"troll":0.0}'),
('SellCheapSS',      'ai_p10', 0, 0, 0, 40, 40, 'Merchant', '{"aggressive":0.2,"friendly":0.6,"troll":0.1}');
